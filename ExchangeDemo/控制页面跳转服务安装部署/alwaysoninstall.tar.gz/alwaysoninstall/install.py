#!/usr/bin/env python
#coding=UTF-8

import os
import sys

import pyinstall
import logging
logging.basicConfig(level=logging.DEBUG,
	format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
	datefmt='%a, %d %b %Y %H:%M:%S',
	filename='install.log',
	filemode='a')

installPath = os.getcwd()
protalInstallFile = "protal.tar.gz"

installFile = {'saradius':'NO', 'mysql':'NO', 'database':'NO', 'node.js':'NO', 'saadmin':'NO', 'rabbitmq':'NO', 'alwayson':'NO','redis':'NO'}

def checkInstallFile():
	pyinstall.printColor('green','\n正在检查安装文件完整性...')
	
	import install_mysql
	import install_database
	import install_alwayson
	import install_radius
	import install_nodejs
	import install_redis
	import install_sa
	import install_rabbitmq

	if install_radius.checkPrecondition():
		installFile['saradius'] = 'YES'

	if install_database.checkPrecondition():
		installFile['database'] = 'YES'

	if pyinstall.checkPrecondition(installPath,'mysql-') != None:
		installFile['mysql'] = 'YES'

	if install_alwayson.checkPrecondition():
		installFile['alwayson'] = 'YES'

	if install_nodejs.checkPrecondition():
		installFile['node.js'] = 'YES'

	if install_redis.checkPrecondition():
		installFile['redis'] = 'YES'

	if install_sa.checkPrecondition():
		installFile['saadmin'] = 'YES'

	if install_rabbitmq.checkPrecondition():
		installFile['rabbitmq'] = 'YES'

	for name,address in installFile.items():
		text = "%-15s [%-3s]" %(name,address)
		pyinstall.printColor('green',text)
		

def main():
	clearYumPID = 'rm -rf /var/run/yum.pid'
	os.system(clearYumPID)
	pyinstall.printColor('green','欢迎使用shopperconnect安装配置程序')
	pyinstall.printColor('green','本程序将引导您进行初次shopperconnect安装工作')
	pyinstall.printColor('green','请依照操作提示完成引导过程...\n')
	logging.debug('开始安装...')
	pyinstall.createTempFile()

	pyinstall.environmentCheck()
	checkInstallFile()

	import install_mysql
	import install_database
	import install_alwayson
	import install_radius
	import install_nodejs
	import install_redis
	import install_sa
	import install_rabbitmq

	if installFile['mysql'] == 'YES':
		install_mysql.main()

	if installFile['database'] == 'YES':
		install_database.main()
		
	if installFile['saradius'] == 'YES':
		install_radius.main()

	if installFile['alwayson'] == 'YES':
		install_alwayson.main()

	if installFile['node.js'] == 'YES':
		install_nodejs.main()
		
	if installFile['redis'] == 'YES':
		install_redis.main()

	if installFile['saadmin'] == 'YES':
		install_sa.main()

	if installFile['rabbitmq'] == 'YES':
		install_rabbitmq.main()

	pyinstall.deleteTempFile(installPath)

if __name__ == "__main__":
	main()
