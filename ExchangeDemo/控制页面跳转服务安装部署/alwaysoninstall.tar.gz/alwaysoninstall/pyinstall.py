#!/usr/bin/env python
#coding=UTF-8

#!/usr/bin/env python
#coding=UTF-8

import os
import string
import time
import sys
import tty
import termios  
import commands
from subprocess import Popen,PIPE
import socket

dbUserName = "root"
rootPassword = "smartac2014"

dbInfo = {'host':'127.0.0.1', 'port':3306,'user':'root','password':'smartac2014', 'database':'shopperconnect','accounting':'radius'}

installPath = os.getcwd()
dbSqlStructureFile = "/smartaccess_structure.sql"
dbSqlDataFile = "/smartaccess_data.sql"
tempSqlFile =  "/temp.sql"
nodejsFile =  "/usr/local/node/bin/node"

firewallSetFalg = 0
'''
功能：检查安装环境，是否是root账户，pcap，mysql，nodejs有没有安装
参数：
返回值：不是root账户，将退出安装
'''	
def environmentCheck():
	printColor('green','正在检查系统环境...')

	env={}
	import install_mysql
	env["mysql-server"] = "NO"
	if install_mysql.checkInstall():
		env["mysql-server"] = "YES"
	
	env["root账户"] = "YES"
	if os.geteuid() != 0:
		env["root账户"] = "NO"

	env["node.js"] = "NO"
	if os.path.isfile(nodejsFile):
		env["node.js"] = "YES"

	env["libpcap"] = "NO"
	if checkLibpcap('/usr/lib64/'):
		env["libpcap"] = "YES"

	for name,address in env.items():
		if name == "root账户":
			text = "%-17s [%-3s]" %(name,address)
			printColor('green',text)
		else:
			text = "%-15s [%-3s]" %(name,address)
			printColor('green',text)

	if env["root账户"] == "NO":
		printColor('red','当前用户不是root账户，请使用root账户启动本安装.')
		sys.exit(1)

def rootCheck():
	printColor('green','正在检查系统环境...')
	env={}

	env["root账户"] = "YES"
	if os.geteuid() != 0:
		env["root账户"] = "NO"
	for name,address in env.items():
		if name == "root账户":
			text = "%-17s [%-3s]" %(name,address)
			printColor('green',text)
		else:
			text = "%-15s [%-3s]" %(name,address)
			printColor('green',text)

	if env["root账户"] == "NO":
		printColor('red','当前用户不是root账户，请使用root账户启动本安装.')
		sys.exit(1)

def tryCopyFile(msg):
	text = "%s正在复制文件..." %msg
	printColor('green',text)

def nodejsInstalled():
	text = "node.js已安装"
	printColor('green',text)
	
def redisInstalled():
	text = "redis已安装"
	printColor('green',text)

def tryConfigFile(msg):
	text = "%s正在配置..." %msg
	printColor('green',text)
	
def tryRunFile(msg):
	text = "%s正在启动..." %msg
	printColor('green',text)

def tryLinkTestMysql(msg):
	text = "%s正在连接测试..." %msg
	printColor('green',text)	

def installMysqlPython():
	text = "正在安装MySQL-Python插件..."
	printColor('green',text)	

def linkMysqOK():
	text = "database连接测试成功"
	printColor('blue',text)

def installNoticeOne():
	text = "数据库已经存在,继续操作将覆盖原始数据库"
	printColor('purple',text)

def installNoticeTwo():
	text = "注意:数据库覆盖将无法恢复!!!!!!"
	printColor('purple',text)
	
def installSuccess(msg,type = 1):
	if type == 1: 
		text = "%s已经成功安装" %msg
		printColor('blue',text)
	else:
		text =  "%s安装失败" %msg
		printColor('red',text)

def initialMysqlError():
	text = "数据库初始化失败!"
	printColor('red',text)
	
def createMysqlError():
	text = "创建radius数据库失败。"
	printColor('red',text)

def linkMysqlError(dif = ''):
	text = "database连接测试失败%s" %dif
	printColor('red',text)

def databaseLoadOK():
	text = "database数据库初始化成功完成"
	printColor('green',text)

def databaseLoadError():
	text = "database数据库初始化失败"
	printColor('red',text)

def databaseLinkOK(msg):
	text =  "%s数据库连接测试成功" %msg
	printColor('green',text)

def databaseLinkError(msg):
	text =  "%s数据库连接测试失败" %msg
	printColor('red',text)

def databaseInputNotice0():
	text = "saRadiusFlag = 0"
	printColor('green',text)

def databaseInputNotice1():
	text = "saRadiusFlag = 1"
	printColor('green',text)
	
def commandExcuv(command):
	i = os.fork()
	if i!=0:
		os.wait()
	else:
		os.execv(command[0],command)

def commandExcuvforWait(command,waitTime):
	j = 0
	i = os.fork()
	pid = 0
	if i!=0:
		time.sleep(waitTime)
		text =  'pid = %d ... 2' %pid
		printColor('red',text)
	else:
		pid = os.getpid()
		text =  'pid = %d ... 1' %pid
		printColor('red',text)
		os.execv(command[0],command)
		
#def procTar(tarFile):
#	commandExcuv(TarCmdGz+[tarFile,])
	
def check_ip(ipaddr): 
	addr = ipaddr.strip().split('.')  #切割IP地址为一个列表 
	#print addr 
	if len(addr) != 4:  #切割后列表必须有4个参数 
		#print "check ip address failed!"
		return False
	for i in range(4): 
		if addr[i] == "":
			#print "check ip address failed!!!"
			return False
		if not addr[i].isdigit():
			#print "check ip address failed!!!!"
			return False
		
		num = string.atoi(addr[i])
		if num <= 255 and num >= 0:    #每个参数值必须在0-255之间 
			continue
		else: 
			#print "check ip address failed!!"
			return False
		i+=1
	return True

def ipAddrInput(msg):
	while True:
		printColor('green',msg,True)
		ipStr = raw_input()
		if ipStr == '':
			return ipStr
		if not check_ip(ipStr):
			text =  "你输入的IP地址不合法,请重新输入！"
			printColor('yellow',text)
			continue
		return ipStr
	
def textReplace(file,oldText,newText):
	file_object = open(file)
	all_the_txt = file_object.read()
	file_object.close()
	all_the_txt = all_the_txt.replace(oldText,newText)
	file_object2 = open(file,'w' )
	file_object2.write(all_the_txt)
	file_object2.close()

def processCheck(pName,tmpfile):
	f = open(tmpfile,'w')#temp.dat
	f.truncate()
	f.close()
	cmdOptLine = '/bin/ps -A|grep %s > %s' %(pName,tmpfile)
	#print cmdOptLine
	os.system(cmdOptLine)
	if os.path.getsize(tmpfile):
		return True
	return False
	
def processOnCheck(pName,tmpfile,mark):
	f = open(tmpfile,'w')#temp.dat
	f.truncate()
	f.close()
	cmdOptLine = '/bin/ps -ef|grep %s > %s' %(pName,tmpfile)
	#print cmdOptLine
	os.system(cmdOptLine)

	input   = open(tmpfile)
	lines   = input.readlines()
	input.close()

	for line in lines:
		#print line
		if not line:  
			break  
		if mark in line:
			return True
	return False

def fileInsertLine(file,addLine,flag,type = 0):
	input   = open(file)
	lines   = input.readlines()
	input.close()
	repeatCheckFlag = 0
	repeatCheckForTail = 0
	buf = ""
	if type == 2:
		buf = buf + addLine + '\n'
	for line in lines: 
		if not line:  
			break  

		if repeatCheckFlag == 1:
			if addLine in line and type == 0:
				buf = buf + line
				repeatCheckFlag = 0
				continue
			else:
				#print addLine
				buf = buf + addLine + '\n'
				buf = buf + line
				repeatCheckFlag = 0
				continue

		if flag in line and type == 0:
			buf = buf + line
			if addLine not in line:
				repeatCheckFlag = 1
		else:
			if type == 1 and flag in line:
				buf = buf + line
				repeatCheckForTail = 1
			else:
				buf = buf + line
		
	if type == 1 and repeatCheckForTail == 0:
		buf = buf + addLine + '\n'
	
	output = open(file,'w');
	output.write(buf)
	output.close()  

def fileTextRepalce(file,flag,replaceText,mark,type = ''):
	input   = open(file)
	lines   = input.readlines()
	input.close()
	buf = ""
	noReplaceFalg = 0
	for line in lines: 
		if not line:  
			break  
		if type != '' and type in line:
			noReplaceFalg = 1
		if flag in line and noReplaceFalg != 1 and mark in line:
			temp = line.split(mark)
			tmp = line.replace(temp[1],replaceText)
			#print ', replaceText = ' + replaceText + ', line = ' + tmp
			buf = buf + tmp
		else:
			buf = buf + line

	output = open(file,'w');
	output.write(buf)
	output.close()  


'''
public function: 
'''	
'''
功能：检索文件
参数：
    filename:要检索的文件名
    paths:可能存在的路径数组
返回值：
    存在：返回文件完整文件路径
    不存在：返回None
'''
def searchFile(filename,paths):
	if filename == '' or paths == None:
		return None

	for i in paths:
		if os.path.exists(i + '/' + filename):
			return i

	return None

'''
功能：有色输出
参数：
    color:颜色代码
        "Red,Yellow,Blue,Green"
    text:要输出的文本
	flag:输出不换行标识
返回值：
    None

'''
def printColor(color,text,flag = False):
	colour = color.lower()
	if colour == 'red':
		if flag:
			iText = '\033[1;31;40m%s\033[0m' %text
			print (iText),
		else:
			print '\033[1;31;40m%s\033[0m' %text
	elif colour == 'yellow':
		if flag:
			iText = '\033[1;33;40m%s\033[0m' 
			print (iText),
		else:
			print '\033[1;33;40m%s\033[0m' %text
	elif colour == 'blue':
		if flag:
			iText = '\033[1;34;40m%s\033[0m' %text
			print (iText),
		else:
			print '\033[1;34;40m%s\033[0m' %text
	elif colour == 'green':
		if flag:
			iText = '\033[1;32;40m%s\033[0m' %text
			print (iText),
		else:
			print '\033[1;32;40m%s\033[0m' %text
	elif colour == 'purple':
		if flag:
			iText = '\033[1;35;40m%s\033[0m' %text
			print (iText),
		else:
			print '\033[1;35;40m%s\033[0m' %text
	else:
		print text

'''
功能：YesNo问题
参数：
	text:问题文本
	default:默认值（True/False）
返回值：
	True/False

'''
def questionYesNo(text,default = True):
   	while True:
		printColor('green',text,True)
		input=raw_input()
		input.lower()
		if default:
			if input == 'y' or input == 'yes' or input == '':
				return True
			else:
				if input == 'n' or input == 'no':
					return False
				else:
					iText = '你的输入不符合要求，请重新输入y(yes)/n(no)!'
					printColor('yellow',iText)
		else:
			if input == 'y' or input == 'yes':
				return True
			else:
				if input == 'n' or input == 'no' or input == '':
					return False
				else:
					iText = '你的输入不符合要求，请重新输入y(yes)/n(no)!'
					printColor('yellow',iText)

'''
功能：是否需要初始化安装
参数：
	moduleName：模块名称
	lineFeed: 是否加换行符
返回值：
	True/False
'''
def installQuery(moduleName,lineFeed,defaultType = 'Y'):
	input = ""
	if moduleName == "database" :
		if lineFeed == 1:
			inputMsg = "\n%s是否需要初始化安装?[y/N]" %moduleName
		else:
			inputMsg = "%s是否需要初始化安装?[y/N]" %moduleName
		if questionYesNo(inputMsg,False):
			return True
		else:
			return False
	else:
		if defaultType == 'Y':
			if lineFeed == 1:
				inputMsg = "\n%s是否需要安装？[Y/n]" %moduleName
			else:
				inputMsg = "%s是否需要安装？[Y/n]" %moduleName
		else:
			if lineFeed == 1:
				inputMsg = "\n%s是否需要安装？[y/N]" %moduleName
			else:
				inputMsg = "%s是否需要安装？[y/N]" %moduleName
	
		if defaultType == 'Y':
			if questionYesNo(inputMsg):
				return True
			else:
				return False
		else:
			if questionYesNo(inputMsg,False):
				return True
			else:
				return False

'''
功能：是否需要覆盖安装
参数：
	moduleName：模块名称
返回值：
	True/False
'''
def replaceInsatallQuery(moduleName):
	inputMsg = "%s当前已经安装,是否覆盖?[y/N]" %moduleName
	if questionYesNo(inputMsg,False):
		return True
	else:
		return False

'''
功能：从终端读按键
参数：
返回值：
	按键的键值

'''
def getch():  
	fd = sys.stdin.fileno()  
	old_settings = termios.tcgetattr(fd)  
	try:  
		tty.setraw(sys.stdin.fileno())  
		ch = sys.stdin.read(1)  
	finally:  
		termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)  
		return ch

'''
功能：密码输入形式（******）
参数：
	maskchar:有按键时的替代显示字符
返回值：
    输入的字符串
'''
def getpass(maskchar = "*"): 
	password = ''
	while True:  
		ch = getch()  
		if ch in '\r\n':  
			print
			return password
		elif ch == '\b' or ord(ch) == 127:  
			if password != '': 
				sys.stdout.write('\b \b')
				sys.stdout.flush()
				password = password[:-1]
		elif ch == '\x03':
			printColor('red','Ctrl + C!')
			sys.exit(1)
		else:
			if maskchar != None:  
				sys.stdout.write(maskchar)  
				password = password + ch

'''
功能：文本输入问题
参数：
	text:问题文本
	default:默认值
	pwd:是否密码输入，如果是密码输入，则默认值和输入都不会显示
返回值：
	True/False

'''
def questionInputText(text, default, pwd = False):
	input = ''
	if	not pwd:
		qText = text + '[%s]'  %default
		printColor('green',qText,True)
		input = raw_input()
	else:
		#sys.stdout.write(text)
		printColor('green',text,True)
		input = getpass('*')
	return input

'''
功能：数据库配置问题
参数：
    dbInfo:数据库配置字典
	moduleName:模块名称
返回值：
    True
    False

'''
def questionDBInfo(dbInfo, moduleName):
	input = ''
	'''
	while True:
		promptText = "%s数据库地址:" %moduleName
		input = questionInputText(promptText,dbInfo['host'])
		if input != '':
			if check_ip(input):
				break
			else:
				if pingIPAddress(input):
					input = DESProcess(input)
					#print input
					break
				else:
					text =  "你输入的IP地址ping不通,请重新输入！"
					printColor('yellow',text)
					continue
		else:
			break
		
	#ipAddrInput(promptText)
	'''
	promptText = "%s数据库地址:" %moduleName
	input = questionInputText(promptText,dbInfo['host'])
	if input != '':
		dbInfo['host'] = input
	
	while True:
		promptText = "%s数据库连接端口:" %moduleName
		input = questionInputText(promptText,str(dbInfo['port']))
		if input != '':
			if input.isdigit():
				dbInfo['port'] = string.atoi(input)
				break
			else:
				printColor('yellow','你输入的类型不正确，请输入数字字符(0-9)！')
		else:
			break
	
	promptText = "%s数据库登录用户:" %moduleName
	input = questionInputText(promptText,dbInfo['user'])
	if input != '':
		dbInfo['user'] = input

	while True:
		promptText = "%s数据库登录密码:" %moduleName
		FirstInput = questionInputText(promptText,dbInfo['password'],True)
		if FirstInput == '':
			break
		secondInput = questionInputText('\t请再输入一次：',dbInfo['password'],True)
		if FirstInput == secondInput:
			dbInfo['password'] = FirstInput
			break
		else:
			#print '两次输入的密码不一致，请重新输入！'
			printColor('yellow','两次输入的密码不一致，请重新输入！')
	
	promptText = "%s数据库名称:" %moduleName
	input = questionInputText(promptText,dbInfo['database'])
	if input != '':
		dbInfo['database'] = input

'''
功能：建数据库连接
参数：
    dbInfo:数据库配置字典
    linkType:连接方式
返回值：
    成功：返回数据库连接
    失败：返回None

'''
def dbConnect(dbInfo,linkType = 0):
	import MySQLdb

	iHost = dbInfo['host']
	iUser = dbInfo['user']
	iPort = dbInfo['port']
	iPasswor = dbInfo['password']
	iDb = dbInfo['database']
	
	if linkType == 2:
		iHost = "127.0.0.1"
		iUser = dbUserName
		iPasswor = rootPassword
		iDb = "mysql"
	if linkType == 1:
		iDb  = "mysql"
	try:
		#print 'host = %s, port = %d, user = %s, password = %s, db = %s'  %(iHost, iPort, iUser, iPasswor, iDb)
		conn = MySQLdb.connect(host = iHost, port = iPort, user = iUser, passwd = iPasswor, db = iDb, connect_timeout = 20, unix_socket="/tmp/mysql.sock")
	except:
		return None
	return conn

'''
功能：执行SQL语句
参数：
    dbInfo:数据库配置字典
    sql:SQL语句
	file:要运行的文件路径。   /usr/local/mysql/bin/mysql
    isfile:sql是否一个文件（如果sql是一个文件，则导入）
返回值：
    返回影响行数
    -1表示执行失败

'''
def executeSQL(dbInfo,sql,file,isfile=True):
	if isfile:
		LogTa = dbInfo['database']
		host = dbInfo['host']   #'127.0.0.1'
		usr = dbInfo['user']
		passwd = dbInfo['password']
		port =dbInfo['port']
		process1 = Popen('%s -h%s -P%s -u%s -p%s %s'  %(file,host, port, usr, passwd, LogTa), stdout=PIPE, stdin=PIPE, shell=True) 
		output1 = process1.communicate('source ' + sql)
		return 1
	else:
		result = 0
		conn = dbConnect(dbInfo)
		if conn == None:
			return -1
		try:
			cursor = conn.cursor()
			result = cursor.execute(sql)
			cursor.close()
		except:
			printColor('red',"创建radius数据库失败。")
			return -1
		return result

'''
功能：在文件中查找
参数：
    file:要搜索的文件
    text:目标文本
    start:开始查找的偏移位置
返回值：
    返回多个值
    返回1：是否找到
    返回2：目标所在偏移
    返回3：目标所在行号

'''
def searchFileText(file,text,start = 0):
	lineNum = 0
	result = True
	fp = open(file,'r')
	remain_the_text = fp.read()
	site = remain_the_text.find(text, start)
	if site == -1:
		result = False

	if result:
		index = 0
		linedata = ''
		fp.seek(0,0)
		lines = fp.readlines()
		fp.close()
		for line in lines:
			lineNum = lineNum + 1
			if text in line:
				lineIndex = line.find(text,0)
				if index + lineIndex >= start:
					linedata = line
					break
				#else:
				#	print index + lineIndex
			index = index + len(line)
	return result,site,lineNum

'''
功能：在文件中替换一行
参数：
	file:要替换的文件
	line:目标行
	text:要替换的文本
	insert:是否插入模式
返回值：
	返回是否成功
'''
def replaceFileLine(file,line,text,insert=False):
	input = open(file)
	lines = input.readlines()
	input.close()
	buf = ""
	lineNum = 0
	for online in lines: 
		if not online:  
			break
		lineNum = lineNum + 1
		if lineNum == line and online != text:
			if insert:
				buf = buf + online
				buf = buf + text
			else:
				#print 'test...'
				buf = buf + text
		else:
			buf = buf + online

	output = open(file,'w');
	output.write(buf)
	output.flush() 
	output.close()  

'''
功能：在文件的一行中替换一段文本
参数：
	file:要替换的文件
	line:目标行
	text:要替换的文本
	mark:被替换的文本
返回值：
	返回是否成功
'''
def replaceFileText(file,line,text,mark):
	input = open(file)
	lines = input.readlines()
	input.close()
	buf = ""
	lineNum = 0
	for online in lines: 
		if not online:  
			break
		lineNum = lineNum + 1
		if lineNum == line and mark in online:
			newLine = online.replace(mark,text)
			buf = buf + newLine
		else:
			buf = buf + online
	output = open(file,'w');
	output.write(buf)
	output.flush() 
	output.close()  	

'''
功能：在文件中替换字符串
参数：
    file:要替换的文件
    offset:目标位置
    size:目标大小
    text:要替换的文本
    insert:(insert = True)插入模式, (insert = False)替换模式
返回值：
    返回是否成功
'''
def replaceFileByte(file,offset,size,text,insert=False):
	fp = open(file,'r')
	remain_the_text = fp.read()
	fp.close
	str1 = remain_the_text[0:offset]
	if insert:
		str2 = remain_the_text[offset + 1:]
	else:
		str2 = remain_the_text[offset + size:]
	buf = str1 + text + str2
	fp = open(file,'w')
	fp.write(buf)
	fp.close()

'''
功能：检查Python MySQL是否安装
参数：
返回值：
    返回是否安装
'''
def checkMySQLd():
	dir = '/usr/lib64'
	list = os.listdir(dir)
	dirMysqlPyhton = 0
	dirMysqlDb = 0
	for line in list:
		if 'python' in line and os.path.isdir(dir + '/' + line):
			path = dir + '/' + line
			if os.path.isdir(path + '/site-packages'):
				iDir = path + '/site-packages'
				PathList = os.listdir(iDir)
				for subLine in PathList:
					if 'MySQL_python' in subLine:
						dirMysqlPyhton = 1
				if os.path.isdir(iDir + '/MySQLdb'):
					dirMysqlDb = 1
	if dirMysqlPyhton == 1 and dirMysqlDb == 1:
		return True
	return False

'''
功能：取得进程PID
参数：
    name：进程标志字串
返回值：
    成功返回PID，失败返回None
'''
def getPID(name):
	cmd = "ps aux | grep '%s' " %name
	info = commands.getoutput(cmd)
	infos = info.split()
	if len(infos) > 1:
		return infos[1]
	else:
		return None
'''
功能：执行命令
参数：
    cmd：启动命令行
    path:启动路径
    fork:是否在后台启动
    wait:是否等待进程结束
返回值：
    成功返回PID，失败返回None
'''
def executeSH(cmd,path,fork,wait=0):
	i = os.fork()
	if i != 0:
		if wait == 0:
			os.wait()
		elif wait > 0:
			time.sleep(wait)
		else:
			print '不需要等待！'
	else:
		if fork:
			subProc = os.fork()
			if subProc != 0:
				 os._exit(0)
			else:
				#os.system(path + cmd)
				os.execv(cmd[0],cmd)
		else:
			os.execv(cmd[0],cmd)
			#os.system(path + cmd)

'''
功能：拷贝文件
参数：
    text:问题文本
    default:默认值
返回值：
    True
    False

'''
CF_Overwrite = True
CF_OverwriteNew = False

def copyFile(source,dest):
	if CF_Overwrite == True:
		#cpRedisServerCmd = ['/bin/cp','-f','-R',source,dest]
		cpRedisServerCmd = 'cp -fR %s %s' %(source,dest)
		executeSH(cpRedisServerCmd,'/bin',False)
'''
功能：获取本机ip地址
参数：
    num：取第几个有效的ipv4的地址
返回值：
    成功：ip地址
	None
'''
def getLocalHostIP(num = 1):
	#hostName = socket.gethostname()
	#localIP = socket.gethostbyname(hostName)#得到本地ip
	#localIP = socket.gethostbyname_ex(hostName)
	#print 'hostname = %s, localIP = %s' %(hostName,localIP)

	order = 1
	localIP = ''
	tmpfile = './temp.dat'
	f = open(tmpfile,'w')
	f.truncate()
	f.close()

	cmdOptLine = '/sbin/ifconfig > %s' %tmpfile
	os.system(cmdOptLine)

	input   = open(tmpfile)
	lines   = input.readlines()
	input.close()

	for line in lines:
		if not line: 
			break
		temp = line.split(' ')
		ipv4 = 0
		for j in temp:
			if j == 'inet':
				ipv4 = 1
			if 'addr:' in j and ipv4 == 1:
				if order == num:
					tmp = j.split(':')
					localIP = tmp[1]
					break
				else:
					order = order +  1
		if localIP != '':
			break
	return localIP

'''
功能：改变root的password
参数：
    num：取第几个有效的ipv4的地址
返回值：
    成功：ip地址
	None
'''	
def changePassword(file,psd):
	newLine = 'rootPassword = "%s"\n' %psd
	
	result,site,line = searchFileText(file,'rootPassword =')
	if result:
		#printColor('yellow','file = %s, line = %d, %s' %(file, line, newLine))
		replaceFileLine(file,line,newLine)
	else:
		result,site,line = searchFileText(file,'rootPassword=')
		if result:
			printColor('yellow','test2...')
			replaceFileLine(file,line,newLine)

'''
功能：检查IP地址的活法性
参数：
    ip：ip地址
返回值：
    True：ping得通
	False：ping不通
'''	
def pingIPAddress(ip):
	count = os.system('ping -c2 -w3 %s > temp.dat'%ip)
	if count:
		return False
	else:
		return True

'''
功能：根据域名取IP地址
参数：
    domain：域名
返回值：
    ip：ip地址
	
'''
def DESProcess(domain):
	result = socket.getaddrinfo(domain,None)
	ip = ''
	for i in result:
		if check_ip(i[4][0]):
			return i[4][0]
	return ip

'''
功能：检查MySQL-Python插件有没有安装，没有就安装
参数：
返回值：
'''	
def installMySQLPython():
	if not checkMySQLd():
		printColor('green','正在安装MySQL-Python插件...')
		pyMysqlInstallCmd = 'yum -y install MySQL-python'
		os.system(pyMysqlInstallCmd)

'''
功能：检查perl插件有没有安装，没有就安装
参数：
返回值：
'''
def installPerl():
	if not os.path.isfile('/usr/bin/perl'):
		perlInstallCmd = 'yum -y install perl'
		os.system(perlInstallCmd)

'''
功能：检查libpcap库有没有安装，没有就安装
参数：
返回值：
'''
def checkLibpcap(path):
	listfile = os.listdir(path)
	for line in listfile:
		if 'libpcap' in line:
			return True
	return False
	
'''
功能：检查libpcap库没有安装，就安装
参数：
返回值：
'''
def installPcap():
	if not checkLibpcap('/usr/lib64/'):
		printColor('green','正在安装libpcap库...')
		libpcapInstallCmd = 'yum -y install libpcap'
		os.system(libpcapInstallCmd)

def waitForTest(wait):
	time.sleep(wait)

'''
功能：mysql创建远程用户
参数：
	conn：数据库连接
	userInfo：数据库用户信息
返回值：
	成功：
'''	
def creatRemoteUserDd(conn,userInfo,domain = '%'):
	import MySQLdb
	try:
		cursor = conn.cursor()
		cmd = "GRANT ALL PRIVILEGES ON *.* TO '%s'@'%s' IDENTIFIED BY '%s' WITH GRANT OPTION;" %(userInfo['user'],domain,userInfo['password'])
		cursor.execute(cmd)
		cursor.execute("FLUSH PRIVILEGES;")
		cursor.close()  
	except MySQLdb.Error,e:
		print "Mysql Error %d: %s" % (e.args[0], e.args[1])
	except:
		pyinstall.initialMysqlError()
		return False
	return True

'''
功能：创建一个临时文件
参数：
返回值：
	成功：创建一个临时文件
'''	
def createTempFile():
	f=open('temp.dat','w') 
	f.close()

'''
功能：删除临时文件
参数：
返回值：
	成功：删除临时文件
'''	
def deleteTempFile(path):
	if os.path.exists(path + '/temp.dat'):
		rmMysqlCmd = 'rm -fR %s/temp.dat' %path
		os.system(rmMysqlCmd)

'''
功能：检查libaio.so.1是否安装
参数：
返回值：
    True:已安装
	False：未安装
'''
def checkLibaio():
	dir = '/lib64'
	list = os.listdir(dir)
	libaioFile = 0
	for line in list:
		if 'libaio' in line and os.path.isfile(dir + '/' + line):
				libaioFile = 1

	if libaioFile == 1:
		return True
	return False

'''
功能：文件或目录查找
参数：
	path：文件路径
	filename：文件名标识
返回值：
    成功:返回文件名或目录
	失败：None
'''
def checkPrecondition(path,filename,type = 'file'):
	list = os.listdir(path)
	data = []
	for line in list:
		if filename in line:
			if type == 'file':
				if os.path.isfile(path + '/' + line):
					data.append(line)
			else:
				if os.path.isdir(path + '/' + line):
					data.append(line)
			
	if len(data):
		return data
	else:
		return None

'''
功能：设置防火墙，将防火墙的规则清掉
参数：
	firewallSetFalg：防护墙清掉的标识
返回值：
    成功:防火墙的规则被清掉
	失败：None
'''
def firewallSet(firewallSetFalg):
	hostIP = getLocalHostIP()
	if hostIP == dbInfo['host'] or dbInfo['host'] != '127.0.0.1' or dbInfo['host'] != 'localhost':
		if firewallSetFalg == 0:
			firewallSetFalg = 1
			setFirewallCmd = 'iptables -F'
			os.system(setFirewallCmd)

			restartFirewallCmd = 'service network restart'
			os.system(restartFirewallCmd)
			restartFirewallCmd = 'service iptables save'
			os.system(restartFirewallCmd)
			return firewallSetFalg
	return firewallSetFalg

'''
功能：写安装日志
参数：
	firewallSetFalg：防护墙清掉的标识
返回值：
    成功:防火墙的规则被清掉
	失败：None
'''
def logInitial():
	import logging
	logging.basicConfig(level=logging.DEBUG,
		format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
		datefmt='%a, %d %b %Y %H:%M:%S',
		filename='install.log',
		filemode='w')
	'''
	if logLevel == 'debug':
		logging.debug(logText)
	elif logLevel == 'info':
		logging.info(logText)
	elif logLevel == 'warning':
		logging.warning(logText)
	elif logLevel == 'error':
		logging.error(logText)
	else:
		logging.debug(logText)
	'''

'''
功能：获取主机名称
参数：
	
返回值：
    成功:主机名称
	失败：None
'''
def hostname():  
	sys = os.name

	if sys == 'nt':
		hostname = os.getenv('computername')  
		return hostname  
	elif sys == 'posix':  
		host = os.popen('echo $HOSTNAME')  
		try:
			hostname = host.read()
			host.close()
			return hostname  
		finally:
			host.close()
	else:  
		return None
	return None

'''
功能：写安装日志
参数：
	name：进程名称
返回值：
    成功:进程号
	失败：0
'''
'''
def get_pid(name):
	#import psutil
	#import re
	
　	process_list = psutil.get_process_list()
　	regex = "pid=(\d+),\sname=\'" + name + "\'"
　	print regex
　	pid = 0
　	for line in process_list:
		process_info = str(line)
		ini_regex = re.compile(regex)
		result = ini_regex.search(process_info)
		if result != None:
			pid = string.atoi(result.group(1))
			print result.group()
			break
	return pid
'''

'''
功能：取配置文件的配置信息
参数：
	file:要替换的文件
	line:目标行
	name:配置项名称
	mark:分割表识
返回值：
	返回是否成功
'''
def getConfigData(file,line,name,mark):
	input = open(file)
	lines = input.readlines()
	input.close()
	buf = ""
	lineNum = 0
	for online in lines: 
		if not online:  
			break
		lineNum = lineNum + 1
		if lineNum == line and name in online:
			temp = online.split(mark)
			return temp[1]
	return None