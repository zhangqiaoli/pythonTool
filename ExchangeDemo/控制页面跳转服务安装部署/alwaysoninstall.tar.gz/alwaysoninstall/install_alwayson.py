#!/usr/bin/env python
#coding=UTF-8

import os

#import sapython
import pyinstall

always = "alwayson"
root = "/smartac"
alwaysonInstallPath = "/smartac/alwayson"

filename = "/alwayson"
alwaysonInsFile = "alwayson.tar.gz"
installPath = os.getcwd()

alwaysonConfFile = "/smartac/alwayson/alwayson.conf"

#����Ƿ��Ѿ���װ
def checkInstall():
	if not os.path.isdir(alwaysonInstallPath):
		return False

	if os.path.isfile(alwaysonInstallPath + filename):
		return True
	return False

#��鰲װǰ���Ƿ�����
def checkPrecondition():
	listfile = os.listdir(installPath)
	for line in listfile:
		if 'alwayson' in line:
			if os.path.isfile(installPath + '/' + line):
				return True
	return False

def copyFile():
	pyinstall.tryCopyFile(always)
	if pyinstall.processOnCheck('python','./temp.dat','alwayson.py'):
		stopAlwaysonCmd = 'service alwayson stop'
		os.system(stopAlwaysonCmd)

	if not os.path.isdir(root):
		mkdirAlwaysonCmd = 'mkdir -p %s' %root
		os.system(mkdirAlwaysonCmd)
	os.chdir(root)
	tarAlwaysonCmd = 'tar -zxvf %s' %(installPath + '/' + alwaysonInsFile)
	os.system(tarAlwaysonCmd)
	
def configFile():
	pyinstall.tryConfigFile(always)

	#pyinstall.fileTextRepalce(alwaysonConfFile, 'enabled=', 'true\n', "=")
	#iNowPath = os.getcwd()
	result,site,line = pyinstall.searchFileText(alwaysonConfFile,'[radiusd]')
	if result:
		result,site,line = pyinstall.searchFileText(alwaysonConfFile,'enabled=',site)
		if result:
			pyinstall.replaceFileText(alwaysonConfFile,line,'true','false')

	result,site,line = pyinstall.searchFileText(alwaysonConfFile,'[radiusCheck]')
	if result:
		result,site,line = pyinstall.searchFileText(alwaysonConfFile,'enabled=',site)
		if result:
			pyinstall.replaceFileText(alwaysonConfFile,line,'true','false')
	
	pyinstall.fileTextRepalce(alwaysonInstallPath + filename, 'basedir=', alwaysonInstallPath + '\n', "=")
	changeModemd = 'chmod 755 %s/alwayson'  %alwaysonInstallPath
	os.system(changeModemd)
	cpAlwaysonCmd = 'cp -fR %s/alwayson /etc/init.d/'  %alwaysonInstallPath
	os.system(cpAlwaysonCmd)


def boot():
	pyinstall.tryRunFile(always)
	startAlwaysonCmd = 'service alwayson start'
	os.system(startAlwaysonCmd)

def main(lineFeed = 1):
	clearYumPID = 'rm -rf /var/run/yum.pid'
	os.system(clearYumPID)
	if not pyinstall.installQuery(always,lineFeed):
		return False
	if checkInstall():
		if not pyinstall.replaceInsatallQuery(always):
			return False

	copyFile()
	configFile()
	boot()
	if pyinstall.processOnCheck('python','./temp.dat','alwayson.py'):
		pyinstall.installSuccess(always)
		addMysqldCmd = 'chkconfig alwayson on'
		os.system(addMysqldCmd)
	else:
		pyinstall.installSuccess(always,0)
	os.chdir(installPath)

if __name__ == "__main__":
	pyinstall.createTempFile()
	pyinstall.rootCheck()
	if checkPrecondition():
		main(0)
	else:
		pyinstall.printColor('red','û��alwayson��װ�ļ���')
	pyinstall.deleteTempFile(installPath)
